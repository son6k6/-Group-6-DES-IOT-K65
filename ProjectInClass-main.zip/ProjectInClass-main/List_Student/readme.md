# Student data list

## Illustration

<img src="https://github.com/gnurt2041/ProjectInClass/blob/main/List_Student/image/Picture1.png" width="650"></h2>

## Software Info

**OS:** Windows

**C version**: < C11
| Software             | Uses               |
|----------------------|--------------------|
| `Visual Studio Code` | Coding and display |


## How to use

With this student data list, you can add one or many new student's data, sort the list with their IDs, find the students that have the same birthday and you can delete these student from the list.
