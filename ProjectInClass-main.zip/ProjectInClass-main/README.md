# This repository include my project in the class at my university

**I’m currently learning Smart Embedded System and IoT. So that my project will focus on 3 programing languages: C/C++ and Python and the technologies around AI, IoT and embedded programming**.
