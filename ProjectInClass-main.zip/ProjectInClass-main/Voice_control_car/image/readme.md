# Image of our project:
**Diagram**

**Circuit design**

**Simulation**

**Result**
