# Image of our project:
**Diagram**
